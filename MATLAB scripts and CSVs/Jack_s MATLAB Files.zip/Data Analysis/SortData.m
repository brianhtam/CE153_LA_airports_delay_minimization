function [ SortedData ] = SortData( Data, Parameter, LorP)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
if LorP == 'L'
    LorP = 1;
elseif LorP == 'P'
    LorP = 2;
else
    disp('Please enter L for Airlines or P for Airports as the LorP variable')
    return
end 

numdata = size(Data,1);
numparam = size(Parameter,1);
SortedData = cell(size(Parameter,1),1);

for i = 1:numdata
    for j = 1:numparam
        if Data(i,LorP) == Parameter{j,2}
            SortedData{j,1}(i,:) = Data(i,:);
        else
        end
    end
end

for j = 1:numparam
    if isempty(SortedData{j,1})
        continue 
    else 
        temp = zeros(sum((SortedData{j,1}(:,LorP) == 0)), 1);
        k=1;
        for i = 1:size(SortedData{j,1},1)
            if SortedData{j,1}(i,LorP) == 0
                temp(k) = i;
                k = k+1;
            else
            end
        end
        SortedData{j,1}(temp,:)=[];
    end
end

end 

