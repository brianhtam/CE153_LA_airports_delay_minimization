function [DataSet] = FlightDataClean(FileName, AorD, Airports, Airlines )
% Start clean
% FileName is the string of the Excel File you wish to clean up including
% the .filetype
% AorD indicates whether the data set is for arrivals or departures. Its
% input is either 'A' or 'D'

% Import Data
DataSet = importdata(FileName);

% Deleting unnecessary text rows
DataSet.textdata(1:2,:) = [];

%Calculating number of arrivals and departures
NumFlights = size(DataSet.data,1);

%Number of airports and airlines
NumAirlines = size(Airlines, 1);      
NumAirports = size(Airports, 1);

%% Numerical Airlines and Airports
% Arrivals to LA basin airports and Departures from LA Basin Airports only
% Turn Airlines into Numbers
SubDataAirlines = zeros(NumFlights,1);
for i = 1:NumFlights
    for j =  1:NumAirlines
        if sum(Airlines{j,1} == DataSet.textdata{i,1}) == 3
            SubDataAirlines(i) = Airlines{j,2};
        else
        end 
    end
end

% Turn Airports into Numbers
SubDataAirports = zeros(NumFlights,1);

if AorD == 'A'
    AorD = 6;
elseif AorD == 'D'
    AorD = 5;
else
    disp('Please enter A for Arrivals or D for Departures as the AorD variable')
    return
end 

for i = 1:NumFlights
    for j =  1:NumAirports
        % Airport codes have a space infront of them
        if sum(Airports{j,1} == DataSet.textdata{i,AorD}(2:4)) == 3 
            SubDataAirports(i) = Airports{j,2};
        else
        end 
    end
end

%% Clean Out Non-regional 

%Departures
DataSet.data(:,1:2) = [SubDataAirlines, SubDataAirports];
temp = zeros(sum(DataSet.data(:,1) == 0),1);
k=1;
for i = 1:NumFlights
    if DataSet.data(i,1) == 0
        temp(k) = i;
        k = k+1;
    else 
    end
end 

DataSet.data(temp, :) = [];

% Clean out NAN entries
temp = zeros(sum(isnan(DataSet.data(1,:))),1);
k=1;
for i = 1:size(DataSet.data,2)
    if isnan(DataSet.data(1,i))
        temp(k) = i;
        k = k+1;
    else 
    end
end 

DataSet.data(:, temp) = [];
DataSet = DataSet.data;
DataSet(:,[3:6]) = DataSet(:,[3:6])*24;
end

