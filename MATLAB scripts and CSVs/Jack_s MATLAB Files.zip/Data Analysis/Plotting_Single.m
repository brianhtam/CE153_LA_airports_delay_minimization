function [FigureNum] = Plotting_Single(SortingMetric, SortedData, ...
    DataLabels, FitOrder, FigureNum )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

for i = 1:length(SortingMetric(:,1))
    if isempty(SortedData{i,1})
        continue
    else
        figure(FigureNum+i)
        clf %ensures no overwriting
        subplot(2,1,1)
        scatter(SortedData{i,1}(:,4),SortedData{i,1}(:,10))
        Fit = polyfit(SortedData{i,1}(:,4),SortedData{i,1}(:,10),FitOrder);
        yfit(i,:) = polyval(Fit,0:.1:24);
        hold on
        plot(0:.1:24, yfit(i,:))
        hold off
        xlabel (DataLabels(4,1))
        ylabel (DataLabels(10,1))
        title (SortingMetric(i,1))
        xlim ([0 24])
        if max(SortedData{i,1}(:,10)) > 0
            ylim ([0 max(SortedData{i,1}(:,10))])
        else
            ylim ([0 1])
        end 
        grid on
        grid minor
        
        if max(SortedData{i,1}(:,10)) > 5
            subplot(2,1,2)
            hist3([SortedData{i,1}(:,4),SortedData{i,1}(:,10)],'Edges',...
                {floor(min(SortedData{i,1}(:,4))) : ceil(max(SortedData{i,1}(:,4))),...
                0 :5:round(max(SortedData{i,1}(:,10)),-1)})
        else
            subplot(2,1,2)
            hist3([SortedData{i,1}(:,4),SortedData{i,1}(:,10)],'Edges',...
                {floor(min(SortedData{i,1}(:,4))) : ceil(max(SortedData{i,1}(:,4))),...
                0 :5:5})
        end 
        
        set(gcf,'renderer','opengl');
        set(get(gca,'child'),'FaceColor','interp','CDataMode','auto');
        xlabel (DataLabels(4,1))
        ylabel (DataLabels(10,1))
        zlabel ('Instances')
        title (SortingMetric(i,1))
        grid on
        grid minor
    end 
end

figure(i+1+FigureNum)
clf

for i = 1:length(SortingMetric(:,1))
    if isempty(SortedData{i,1}) 
        plot(0:.1:24, zeros(1,length(0:.1:24)))
    else
        plot(0:.1:24, yfit(i,:))
        ylim([0,30])
    end 
    hold on
end


legend(SortingMetric(:,1))
FigureNum = i+FigureNum+1;

end

