function [ SortedAirlines, SortedAirports, FigureNum ] = Preliminary_Data_Visuals( File, FitOrder )
%% Compiling Elements 
% Ensure you have the file Data Analysis Downloaded
% The folder Data Analysis should be placed in the Matlab search path so 
%  that the functions can be invoked from any folder; to place it on the 
%  search path select Set Path from the Matlab Homew Menu, then Add Folder,
%  select the folder and click ok to add the folder to the path;

%Data Columns: Carrier Airport PlanOut ActualOut PlanIn ActualIn
% UnimpededTaxiOutTime TaxiOutTime TaxiOutTimeDifference TaxiOutDelay
% EstimatedTimeEnroute ActualAirborneTime AirborneTimeDifference AirborneDelay 
% UnimpededTaxiInTime TaxiInTime TaxiInTimeDifference TaxiInDelay ScheduledBlockTime
% ActualBlockTime BlockTimeDifference BlockDelay

% Determine if file is Arrival or Departure file
if File(1:3) == 'arr'
    AorD = 'A';
elseif File(1:3) == 'dep'
    AorD = 'D';
else
end 

%% Definitions
% Defining Airlines - Looking at domestic airlines.  Numbered
% alphabetically
Airlines = {'AAL' 1;... %American Airlines
            'AAY' 2;.... %Allegiant
            'ASA' 3;... %Alaska
            'ASH' 4;... %Mesa**REGIONAL
            'CPZ' 5;... %Compass
            'DAL' 6;... %Delta
            'FFT' 7;... %Frontier 
            'GLA' 8;... %Great Lakes Airlines
            'HAL' 9;... %Hawaiian 
            'JBU' 10;... %Jet Blue
            'MHO' 11;... %Mokulele
            'NKS' 12;... %Spirit
            'SCX' 13;... %Sun Country
            'SKW' 14;... %Sky West
            'SWA' 15;... %SouthWest
            'UAL' 16;... %United
            'VRD' 17}; %Virgin America

%Define Airports - Numbered alphabetically
Airports = {'BUR' 1;... %Burbank
            'LAX' 2;... %Los Angeles
            'LGB' 3;... %Long Beach
            'ONT' 4;... %Ontario
            'SNA' 5}; %John Wayne
        
% Columns of clean data
Columns = { 'Carrier'               1;...
            'Airport'               2;...
            'FlightPlanGateOut'     3;...
            'ActualGateOut'         4;...
            'FlightPlanGateIn'      5;...
            'ActualGateIn'          6;...
            'UnimpededTaxiOutTime'  7;...
            'TaxiOutTime'           8;...
            'TaxiOutTimeDifference' 9;...
            'TaxiOutDelay'          10;...
            'EstimatedTimeEnroute'  11;...
            'ActualAirborneTime'    12;... 
            'AirborneTimeDifference' 13;...
            'AirborneDelay'         14;...
            'UnimpededTaxiInTime'   15;...
            'TaxiInTime'            16;...
            'TaxiInTimeDifference'  17;...
            'TaxiInDelay'           18;...
            'ScheduledBlockTime'    19;...
            'ActualBlockTime'       20;...
            'BlockTimeDifference'   21;...
            'BlockDelay'            22};
        
%% Clean Up Data
% FileName is the string of the Excel File you wish to clean up including
% the .filetype
% AorD indicates whether the data set is for arrivals or departures. Its
% input is either 'A' or 'D'
DataSet = FlightDataClean(File, AorD , Airports, Airlines );

%% Sort Data
SortedAirlines = SortData( DataSet, Airlines, 'L');
SortedAirports = SortData( DataSet, Airports, 'P');

% Checking if sorting worked
l=0;
p=0;
for i = 1:size(SortedAirlines, 1)
    l = l + size(SortedAirlines{i,1},1);
end 
for i = 1:size(SortedAirports, 1)
    p = p + size(SortedAirports{i,1},1);
end 
if l == size(DataSet, 1) && p == size(DataSet, 1)
    disp('Your sorting worked')
else
    disp('Your sorting didn''t work. CHECK THE CODE')
end 

%% Plotting

FigureNum = 0;
[FigureNum] = Plotting_Single(Airlines, SortedAirlines, Columns,FitOrder, FigureNum);
[FigureNum] = Plotting_Single(Airports, SortedAirports, Columns,FitOrder, FigureNum);

end

